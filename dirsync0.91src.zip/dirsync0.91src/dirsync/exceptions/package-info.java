/**
 * Provides the special exceptions thrown in DirSync.
 */
package dirsync.exceptions;