/**
 * Provides the classes necessary to model the Synchronization.
 */
package dirsync.sync;