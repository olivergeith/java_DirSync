/**
 * Provides tools for DirSync.
 */
package dirsync.tools;