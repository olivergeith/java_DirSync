/**
 * Provides the base classes for DirSync.
 */
package dirsync;