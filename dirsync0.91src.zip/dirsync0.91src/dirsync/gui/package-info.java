/**
 * Provides the classes for the graphical user interface (GUI) of DirSync.
 */
package dirsync.gui;