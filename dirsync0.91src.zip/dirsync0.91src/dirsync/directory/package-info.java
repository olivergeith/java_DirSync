/**
 * Provides the classes necessary to model a Directory.
 */
package dirsync.directory;