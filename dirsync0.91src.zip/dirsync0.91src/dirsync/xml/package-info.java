/**
 * Provides the necessary classes to read and write directory definitions in XML (eXtensible Markup Language).
 */
package dirsync.xml;