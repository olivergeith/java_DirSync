rm dirsync.jar
jar cmf MANIFEST.MF dirsync.jar dirsync icons help